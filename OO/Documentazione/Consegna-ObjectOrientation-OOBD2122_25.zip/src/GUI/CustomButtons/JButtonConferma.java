package GUI.CustomButtons;

import javax.swing.*;
import java.awt.*;

public class JButtonConferma extends JButtonGreen {
    public JButtonConferma() {
        super("Conferma");
    }
}
