package GUI.CustomButtons;

import javax.swing.*;
import java.awt.*;

public class JButtonAnnulla extends JButtonGrey {

    public JButtonAnnulla() {
        super("Annulla");
    }
}
