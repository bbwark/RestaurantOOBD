I file sono stati prodotti attraverso il software pgAdmin4 per PostgreSQL che fa uso di pg_dump.

Nella cartella "Custom" l'export è stato fatto in formato CUSTOM, facilmente importabile da pgAdmin4 su un database per poter ricreare la base di dati all'interno.

Nella cartella "Plain" l'export è stato fatto in formato PLAIN, il più diffuso.
