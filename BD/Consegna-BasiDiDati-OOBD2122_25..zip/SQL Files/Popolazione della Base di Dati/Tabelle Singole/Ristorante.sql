INSERT INTO "Ristorante" ("Nome_Ristorante") VALUES ('Pasta d Oro');
INSERT INTO "Ristorante" ("Nome_Ristorante") VALUES ('il Rametto');
INSERT INTO "Ristorante" ("Nome_Ristorante") VALUES ('Manhattan');